# -*- coding: utf-8 -*-
"""Detect Unity Capture and VB-CABLE. This app supports Unity Capture only."""
import sys

def is_windows():
    return sys.platform.startswith("win")

def list_dshow_cameras():
    """Read DirectShow names from the standard Windows device-category registry."""
    if not is_windows():
        return []
    try:
        import winreg
        cat = "CLSID\\{860BB310-5D01-11d0-BD3B-00A0C911CE86}\\Instance"
        paths = ["SOFTWARE\\Classes\\" + cat,
                 "SOFTWARE\\Classes\\WOW6432Node\\" + cat,
                 "SOFTWARE\\WOW6432Node\\Classes\\" + cat]
        found, seen = [], set()
        for path in paths:
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path) as key:
                    for i in range(winreg.QueryInfoKey(key)[0]):
                        try:
                            child = winreg.EnumKey(key, i)
                            with winreg.OpenKey(key, child) as dev:
                                name, _ = winreg.QueryValueEx(dev, "FriendlyName")
                            if name and str(name) not in seen:
                                seen.add(str(name)); found.append(str(name))
                        except OSError:
                            continue
            except OSError:
                continue
        return found
    except Exception:
        return []

def check_unity_capture_installed():
    return any("unity" in name.lower() for name in list_dshow_cameras())

def check_cable_installed():
    try:
        from audio_engine import PhoneNoiseEngine
        names = [n.lower() for _, n in (PhoneNoiseEngine.list_output_devices() + PhoneNoiseEngine.list_input_devices())]
        return any("cable" in n and ("vb" in n or "virtual" in n) for n in names)
    except Exception:
        return False

def detect_vcam_backends():
    return {"unity": check_unity_capture_installed()}

def devices_status_report():
    unity_names = [n for n in list_dshow_cameras() if "unity" in n.lower()]
    rows = [("Unity Capture virtual camera", bool(unity_names),
             ("detected: " + ", ".join(unity_names)) if unity_names else
             "not detected — install/enable Unity Capture; this app will not fall back to another camera")]
    cable = check_cable_installed()
    rows.append(("VB-CABLE virtual microphone", cable,
                 "detected" if cable else "not detected — install VB-CABLE and restart Windows"))
    try:
        from audio_engine import PhoneNoiseEngine
        idx, name = PhoneNoiseEngine.find_cable_device()
        rows.append(("App audio output", idx is not None,
                     f'"{name}"' if idx is not None else "CABLE Input not found"))
    except Exception:
        rows.append(("App audio output", False, "audio module unavailable"))
    try:
        import pyvirtualcam
        rows.append(("pyvirtualcam Unity backend", True, "available"))
    except Exception:
        rows.append(("pyvirtualcam Unity backend", False, "install dependencies from requirements.txt"))
    return rows

def run_camera_uninstaller(script_path):
    """Launch the explicitly-confirmed destructive uninstaller with UAC elevation."""
    if not is_windows():
        return False, "Windows-only camera uninstall."
    import os
    import subprocess
    if not os.path.isfile(script_path):
        return False, f"Not found: {script_path}"
    arglist = f'-NoProfile -ExecutionPolicy Bypass -File "{script_path}"'
    escaped = "'" + arglist.replace("'", "''") + "'"
    command = "Start-Process -FilePath powershell.exe -Verb RunAs -ArgumentList " + escaped
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-Command", command])
        return True, "Elevated camera-removal prompt opened."
    except Exception as e:
        return False, str(e)


def run_diagnose_script(script_path):
    if not is_windows():
        return False, "Windows-only diagnostic."
    import os, subprocess
    if not os.path.isfile(script_path):
        return False, f"Not found: {script_path}"
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script_path])
        return True, "Unity Capture diagnostic opened."
    except Exception as e:
        return False, str(e)
