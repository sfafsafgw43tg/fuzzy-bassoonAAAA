# 📱 Realme 12 Pro Studio

**Wirtualna kamera Unity Capture + wirtualny mikrofon VB-CABLE** — projekcja zdjęć i nagrań
w formatach telefonowych + **losowe szumy mikrofonu telefonu**
generowane na żywo. **W 100% OFFLINE.** Start przez dwuklik pliku `.BAT`. 🖥️

---

## ✨ Co potrafi aplikacja

### 📷 Projektor obrazu (Unity Capture only)
- Wczytuje **zdjęcia** (JPG/PNG/WebP/BMP) i **nagrania** (MP4/AVI/MKV/MOV/WebM)
- Formaty telefonowe: **Realme 12 Pro 1080×2412 (20:9, natywny)**, Full HD pion,
  HD, QHD, 4K pion, Full HD poziom, kwadrat, Story
- Pokaz slajdów: ręczny / auto / **losowy**, z przejściami (przenikanie, przez czerń)
- Efekty „żywego telefonu”: drganie ręki, ziarno, winieta, animowany **autofocus**
- Nakładka aparatu **Realme UI**: REC, data/godzina, podpis „Realme 12 Pro 50MP OIS”, bateria
- Filtry: Żywy, Nocny, B&W, Sepia, Chłodny, Ciepły • obrót, lustro, FPS
- **Unity Capture only**: the app is locked to the clearly identified Unity virtual camera; there is no other camera backend.
- **Kadrowanie ręczne**: chwyć zdjęcie myszką i ustaw w kadrze, kółko = zoom,
  suwaki Zoom/X/Y, szybkie pozycje (środek/góra/dół/lewo/prawo) — każde zdjęcie
  **pamięta własny kadr**; tryb **telefonu na długość** (poziomo/panorama)

### 🎬 Odtwarzacz nagrania (pod podglądem — jak w normalnym playerze)
- Pasek sterowania jest **tylko dla nagrań** (`mp4/avi/mkv/mov`) — przy zdjęciu lub
  planszy AI znika razem z wierszem, więc pokaz slajdów nie ma niepotrzebnego transportu
- **⏮ ▶/❚❚ ⏹ ⏭** — poprzedni materiał, start/pauza, stop (powrót na 0), następny materiał;
  pauza nie gasi kamery — rozmówca widzi **zamrożoną ostatnią klatkę**
- **Suwak czasu** z podpisem `00:04 / 00:10` — kliknij lub przeciągnij, skok w dowolne miejsce
- **−5 s / +5 s** — skoki w tył i w przód
- **🔁 Zapętl nagranie** + **„Płynny szew” (0–1,2 s)** — ostatnie klatki **rozpływają się**
  w pierwsze, więc powtórka nie trzaska cięciem (crossfade liczony w klatkach pliku)
- Wyłączona pętla = nagranie **staje na ostatniej klatce** (1 materiał) albo przechodzi do
  następnego (pokaz auto/losowy) — bez ucinania długich nagrań po 18 s

### 🎙 Generator szumu mikrofonu (losowy, jak z telefonu)
- Szum własny mikrofonu + przydźwięk 50 Hz + otoczenie — syntezowane na żywo (48 kHz)
- Scenerie: 🏠 pokój, 🏙️ ulica, 🍃 wiatr, ☕ tłum, 🚗 samochód, 🌧️ deszcz, 🌙 noc, 🎲 losowy AI
- Losowe zdarzenia: trzaski, puknięcia, tarcie o ubranie, podmuchy wiatru,
  przejeżdżające auta, gwar, kierunkowskaz, daleki grzmot…
- Regulacja: głośność, poziom szumu, częstotliwość zdarzeń, basy, wyciszenie
- Wskaźnik poziomu **VU meter** na żywo
- **Oddech**: cichy, naturalny oddech jak z telefonu blisko ust + westchnięcia i sapnięcia
  (włącznik = wyciszenie, suwaki: głębokość i tempo /min)

- **Bezpieczny dźwięk**: blokada „tylko wirtualne kable” — szum gra wyłącznie do kabla,
  nigdy na głośniki bez wyraźnego ostrzeżenia (nie miesza się z odbieranym dźwiękiem)

### 🎵 Oś czasu audio — muzyka, dźwięki, głos (zakładka **Audio**)
- Dodajesz **pliki audio** (mp3, wav, ogg, flac, m4a…) — pokazują się jako bloki na **osi czasu**
- **▶ Odtwarzaj / ❚❚ Pauza / ■ Stop**, wznowienie od miejsca pauzy, skok **+5 s / −5 s**,
  kliknięcie w oś = przeskok do wybranego fragmentu, **Pętla** i **Odtwórz wybrany klip**
- Głośność całej muzyki i **osobno każdego klipu**, cisza pojedynczego klipu
- Muzyka leci **razem z szumem mikrofonu** (miks) → rozmówca słyszy jedno i drugie
- **🔊 Odsłuch**: słyszysz to u siebie (głośniki/słuchawki) z własną głośnością —
  odsłuch **nie zmienia** tego, co idzie do kabla
- **⏺ Nagrywanie** dokładnie tego, co leci na wirtualny mikrofon → plik WAV (16 bit)
- **Pauza mikrofonu** — jedna kratka = cisza na wyjściu (np. gdy mówisz do telefonu)

### 🗣 Mowa z tekstu (TTS) — zakładka **Mowa (TTS)**
- Wpisujesz tekst → aplikacja **wypowiada go** do wirtualnego mikrofonu (obok szumu telefonu)
- **Silniki w 100% offline**: Windows `System.Speech` (wbudowane głosy SAPI, np. *Microsoft Zosia*),
  `espeak-ng` z PATH, ewentualnie `pyttsx3` — pierwszy działający wygrywa. Bez klucza API
  **żaden bajt nie opuszcza komputera**; po wklejeniu klucza w zakładce **Prywatność**
  możesz kazać mówić modelowi z chmury ( Natural / OpenAI-kompatybilne ``/audio/speech``)
- Wybór **głosu** (z listy zainstalowanych w systemie), **tempa** (−10…+10) i **głośności**
- **🔊 Mów do mikrofonu** = mowa wchodzi na oś czasu i gra razem z szumem mikrofonu
  (rozmówca słyszy i to, i to; nagrywanie WAV łapie obie rzeczy)
- **➕ Do osi czasu** — tylko dokłada klip, bez grania od razu · **💾 Zapisz WAV…** — plik do archiwum
- **⏹ Stop** — natychmiastowe wyciszenie mowy

### 🔑 Klucze API i prywatność (opcjonalne — zakładka **Prywatność**)
- **Domyślnie: offline.** Nic nie jest wysyłane, dopóki nie wkleisz klucza **i** nie zaznaczysz zgody
- **Mowa (TTS) z chmury** — klucz + model + głos (alloy/nova/onyx…) → `POST /audio/speech`;
  jak chmura nie da rady, aplikacja **sama wraca na silnik lokalny** i mówi o tym w logu
- **AI Wideo: konsultacja planu** — kliknij **🌐 Zapytaj AI o plan** w zakładce AI Wideo:
  model dostaje Twój prompt i liczby planu, a odpowiada **wyłącznie** liczbami z dozwolonej
  listy (klip s, ruch, ziarno, winieta, kolory, przejścia, fps…). Każda wartość jest sprawdzana
  i przycinana do zakresu; nic poza planem nie może zmienić
- **Trzy osobne zgody**: tekst mowy · treść promptu · **miniatury zdjęć** (max 4, ~384 px, JPEG)
  — bez kliknięcia nic nie wychodzi, a miniatury są wyłączone nawet przy włączonym kluczu
- **ⓘ przy każdej sekcji** otwiera pudełko z uczciwym opisem: co leci, dokąd, gdzie mieszka
  klucz, jak to wyłączyć — bez prawniczej mgły
- **Klucze**: w config.json (plik tekstowy!), **nigdy** w presetach ani w dzienniku; są zakryte
  kropkami w polu (są przyciski „Pokaż” i „Wklej ze schowka”), a przy **Przywróć ustawienia
  fabryczne** i „Wyczyść klucze” znikają bezpowrotnie
- Adres API może wskazywać **własny serwer** (Ollama, LM Studio, LocalAI, vLLM, LiteLLM) —
  przez czysty `http://` klucz poleciałby jawnie, więc aplikacja zgadza się na to
  **tylko dla localhost**; w drugą stronę wymaga https
- **Zero nowych zależności**: klient to czysta biblioteka standardowa Pythona (`urllib`)

### 🤖 AI Wideo — film ze zdjęć, darmowe i OFFLINE (zakładka **AI Wideo**)
- **Piszesz prompt po polsku**, np. *„kinowy film 30 sekund, wolne najazdy, sepia, ziarno,
  cięcia w rytm muzyki”* — AI zamienia to na **plan filmu** (liczby, nie „czary”)
- **Akceptujesz prompt** → widzisz dokładnie, co AI zrobi (ruch, cięcia, kolory, format, długość)
- **Biblioteka 12 gotowych stylów**: Kinowy spokojny, TikTok/Reels, Retro VHS 1998,
  Czarno-białe kino, Sen, Mroczny thriller, Vlog, Wywiad, Nostalgia, Wakacje, Sport, Glitch cyber
- Renderuje film: **ken burns** (najazd/odjazd), panoramy, obroty, drganie kamery,
  ziarno, winieta, migotanie, look (B&W/sepia/vintage/ciepły/zimny/kinowy), rozmycie,
  **przejścia** (przenikanie, przesuw, błysk, glitch, ostre cięcie)
- **Cięcia w rytm muzyki** z osi czasu (lokalny detektor uderzeń) albo równe cięcia
- Jakość **720p / 1080p** (pion, poziom, kwadrat, 4:5), 30 fps, pasek postępu i **anulowanie**
- **Uczenie się AI (lokalne)**: każdy zaakceptowany prompt zapisuje się w `ai_learning.json`
  i wpływa na kolejne filmy — AI coraz lepiej trafia w Twój styl. **Bez internetu, bez chmury.**
- Gotowy film jednym kliknięciem **dodasz do playlisty** aplikacji (i puścisz przez wirtualną kamerę)

### 💾 Ustawienia: zapis, wczytanie, presety (przycisk **⚙ Ustawienia**)
- **Cały stan aplikacji** (format, kadr, filtry, efekty, nakładki, dźwięk, oś czasu, AI, mowa)
  zapisujesz do **jednego pliku JSON** i wczytasz w sekundę — na drugiej maszynie albo po zmianie scenerii
- **Szybkie presety** w folderze `presets/`: „spotkanie”, „stream wieczór”, „test mikrofonu” —
  lista w oknie ustawień, klik = wczytanie, ✕ = usuń
- **Auto-zapis do `config.json` przy zamknięciu** — można wyłączyć jednym kliknięciem
  (wtedy plik ustawień zostaje nietknięty); **Ctrl+S** zapisuje od ręki
- **Przywróć ustawienia fabryczne** — wraca do domyślnych wartości, ale **Twoja playlista
  i zapamiętane kadry zdjęć zostają**
- Wczytanie ustawień **nie wymaga restartu**: aplikacja aktualizuje suwaki, zakładki
  i silniki (kamera/dźwięk) na żywo

### 🖥 Jawnie oznaczone urządzenia wirtualne
- Kamera: **Unity Capture (virtual)**; keep its default driver label.
- Mikrofon: **CABLE Output (VB-Audio Virtual Cable)**.
- Nazwy pozostają domyślne; aplikacje spotkań pokazują, że są to urządzenia wirtualne.
- **Remove all cameras** in the Devices window is an elevated, double-confirmed Windows operation. It includes built-in webcams; driver/registry backups go to `C:\ProgramData\CameraDriverBackup`. Windows may rediscover hardware. See `UNINSTALL_ALL_CAMERAS.txt`.

---

## 🚀 Szybki start (Windows)

| Krok | Co zrobić |
|------|-----------|
| 1 | Uruchom **`INSTALUJ.bat` → opcja 1** — instaluje Python, biblioteki i VB-CABLE; Unity Capture instalujesz osobno. |
| 2 | Zainstaluj i uruchom **Unity Capture** (link w oknie Urządzenia). |
| 4 | Zainstaluj **VB-CABLE** → https://vb-audio.com/Cable/ (darmowe) → **restart PC** |
| 5 | Uruchom nadajnik Unity Capture; pozostaw standardową nazwę sterownika. |
| 6 | Na co dzień: dwuklik **`START_REALME_CAM.bat`** → dodaj media → **▶ START NADAWANIA** |
| 7 | W komunikatorze wybierz **Unity Capture (virtual)** i **CABLE Output (VB-Audio Virtual Cable)** |
| 8 | *(opcjonalnie)* **Audio** → dodaj muzykę, włącz **Odsłuch**, by słyszeć ją u siebie |
| 9 | *(opcjonalnie)* **AI Wideo** → wpisz prompt → **Akceptuj prompt** → **Renderuj film** |

> 📂 Własne zdjęcia/filmy możesz po prostu wrzucać do folderu **`media/`** —
> aplikacja wczyta je automatycznie przy starcie.

## ⌨ Skróty
- `←` / `→` — poprzedni / następny slajd
- `Spacja` — pauza / wznowienie muzyki (zakładka **Audio**)
- `Ctrl+Spacja` — **▶ / ❚❚ bieżącego nagrania** (start / pauza)
- `Ctrl+→` / `Ctrl+←` — skok **+5 s / −5 s** w nagraniu
- `Ctrl+L` — włącz / wyłącz **pętlę** nagrania
- `Ctrl+S` — **zapisz ustawienia** do `config.json` (ten sam efekt co przy zamknięciu)
- `Ctrl+R` — start/stop nagrywania mikrofonu • `Ctrl+M` — odsłuch on/off

## 📁 Struktura projektu

```
realme12pro-studio/
├── START_REALME_CAM.bat     ← codzienny start (DWUKLIK)
├── INSTALUJ.bat             ← instalacja (raz)
├── USTAW_URZADZENIA.bat     ← instrukcje wyboru urządzeń
├── app.py                   ← aplikacja (GUI)
├── ui_v13.py                ← zakładki „Audio” i „AI Wideo” (UI + logika)
├── ui_v14.py                ← pasek odtwarzacza, pętla z płynnym szwem, TTS, ustawienia
├── tts_engine.py            ← lokalny TTS: System.Speech / espeak-ng / pyttsx3 → WAV
├── cloud_net.py             ← opcjonalne klucze API (mowa + konsultacja planu) i prywatność
├── audio_engine.py          ← generator szumów telefonu (miks muzyki, pauza, odsłuch)
├── audio_timeline.py        ← oś czasu audio, dekodowanie, nagrywanie, detektor uderzeń
├── ai_video.py              ← darmowe AI offline: prompt → plan → film ze zdjęć
├── video_engine.py          ← projektor zdjęć/nagrań → wirtualna kamera + transport/pętla
├── virtual_devices.py       ← wykrywanie Unity Capture / VB-CABLE
├── phone_formats.py         ← formaty telefonowe
├── scripts/rename_devices.ps1 ← bezpieczny stub (nie zmienia nazw)
├── media/                   ← TU WRZUĆ SWOJE ZDJĘCIA I FILMY
├── assets/                  ← ikona, grafiki
├── output/                  ← wyrenderowane filmy AI + wygenerowana mowa (WAV)
├── presets/                 ← Twoje zapisane ustawienia (⚙ Ustawienia)
├── config.example.json      ← szablon ustawień (opcjonalnie skopiuj do config.json)
├── config.json              ← ustawienia na żywo (zapisywane przy zamknięciu)
├── ai_learning.json         ← lokalna pamięć stylów AI (powstaje po 1. filmie)
└── requirements.txt
```

> 🙈 **Te pliki powstają u Ciebie i NIE są w repozytorium** (`.gitignore`):
> `config.json` (ustawienia zapisywane przy zamknięciu aplikacji),
> `ai_learning.json` (lokalna pamięć stylów AI), `output/` (wyrenderowane filmy)
> oraz `INSTALACJA_LOG.txt` / `DIAGNOZA_KAMERY.txt`.
> Aplikacja sama tworzy `config.json` z wartości domyślnych, więc czyste
> clone uruchamia się bez żadnych przygotowań.

## 🔧 Jak to działa technicznie

- **Obraz:** OpenCV renderuje klatki → `pyvirtualcam` wysyła je do sterownika
- The app outputs only through **Unity Capture**; device name is not changed.
  w rejestrze (`HKLM\...\CLSID\{A3FCE0F5-...}` + gałąź `WOW6432Node`).
- **Dźwięk:** `numpy` + `sounddevice` syntezują szum w czasie rzeczywistym i grają go
  on **CABLE Input (VB-CABLE)**; select the clearly labeled **CABLE Output (VB-Audio Virtual Cable)** in meeting apps.

- **Oś czasu audio:** `numpy` miksuje szum z muzyką w tym samym strumieniu (48 kHz),
  a kopia sygnału (`RingTap`) zasila **odsłuch** (osobny strumień na głośniki) i **nagrywanie WAV**.
- **AI Wideo:** lokalny silnik efektów (OpenCV) + parser promptów PL + pamięć stylów
  w pliku JSON. Żadnego modelu w chmurze, żadnego API, żadnych zapytań sieciowych.
- **Odtwarzacz / pętla:** `cv2.VideoCapture` + licznik klatek (`CAP_PROP_POS_FRAMES`).
  Pauza = trzymanie ostatniej klatki (`_frozen`), przewijanie = `seek` z awaryjnym
  „przewiń odczytując” dla kodeków ignorujących seek. **Płynny szew:** przy końcu pliku
  bufor ostatnich klatek ogona (limit ~28 MB) jest *rozpływany* w pierwsze klatki
  (`cv2.addWeighted`, waga rośnie klatka po klatce), więc powtórka nie trzaska.
- **TTS:** `tts_engine.py` odpala lokalny silnik (Windows: `System.Speech` przez PowerShell,
  zapis do WAV 44,1 kHz; alternatywy: `espeak-ng`, `pyttsx3`) → WAV wchodzi na oś czasu
  audio i miksuje się z szumem mikrofonu. Domyślnie tylko głosy systemu; `cloud_net.py`
  dokłada opcjonalną ścieżkę chmurową (klucz + zgoda), z awaryjnym powrotem na lokalny silnik.
- **Chmura:** `cloud_net.py` = `urllib` + `json`, bez zależności. Brama to `enabled(net, co)`:
  provider + klucz + **zgoda** + https/localhost. `scrub()` wycina klucz z każdego komunikatu,
  `redact()` wycina go z presetów, a `parse_patch()`/`merge_plan()` przyjmują od modelu tylko
  białą listę pól planu w zakresach. Bez zgody żadne żądanie nie zostaje nawet złożone.
- **Ustawienia:** cały stan aplikacji to jeden słownik `CFG` (sekcje `video`/`audio`/`ai`/
  `tts`/`ui`), zapisywany i walidowany przy wczytaniu sekcja po sekcji, a potem „wcpany”
  w widgety i silniki przez te same handlery, których używa GUI.
- Wszystko lokalne — **żadnego internetu, żadnego serwera**, dopóki sam nie wkleisz klucza
  i nie klikniesz zgody (wtedy jedynym celem jest adres, który wpisałeś).

## ❓ Rozwiązywanie problemów

- **Unity Capture nie działa** → upewnij się, że sterownik Unity Capture jest zainstalowany i źródło działa. Aplikacja nie przełącza się na inne kamery.
- **Kamera nie pojawia się na liście** → upewnij się, że Unity Capture jest zainstalowany i uruchomiony. Jeśli nadal jej nie widać, najczęstszy powód to
  pamięć podręczna komunikatora: **zamknij go CAŁKOWICIE** (także z zasobnika) i otwórz
  ponownie. Potem: `USTAW_URZADZENIA.bat` (pokazuje standardowe nazwy i panel urządzeń) → `DIAGNOZUJ_KAMERE.bat`
  (sekcja [4] raportu pokazuje, co widzą programy).
- **Nie ma kamery na liście** → uruchom Unity Capture → zrestartuj komunikator.
- **Nie ma mikrofonu** → sprawdź Panel sterowania → Dźwięk → Nagrywanie → czy jest CABLE Output.
- **Błąd pyvirtualcam** → `pip install --upgrade pyvirtualcam`, upewnij się, że Unity Capture jest zainstalowany i aktualny.
- **Aplikacja nie startuje** → uruchom `INSTALUJ.bat` ponownie, sprawdź Python 3.10+ z PATH.
- **4K tnie** → przełącz format na 1080×2412 lub 720×1600.
- **Nie słychać muzyki w komunikatorze** → w zakładce **Audio** sprawdź, czy utwór gra
  (▶ i pasek pozycji), a wyjście dźwięku to **CABLE Input**. Do własnego ucha użyj **Odsłuchu**.
- **Nie mogę dodać mp3/m4a** → doinstaluj dekoder: `pip install miniaudio`
  (albo zainstaluj ffmpeg). WAV i OGG działają zawsze.
- **Film AI wyszedł duży** → to głównie ziarno. Wybierz **720p**, zmniejsz **Ziarno filmowe**
  albo ustaw cel 15–20 s. Na Windows zapis idzie kodekiem **H.264**, więc pliki są mniejsze.
- **Nie ma głosów TTS / mowa cicha** → Windows: Ustawienia → *Czas i język* → **Mowa**
  → dodaj głos (np. „Microsoft Zosia”). Aplikacja używa **tylko** tego, co jest w systemie.
  Linux: `sudo apt install espeak-ng`. Można też `pip install pyttsx3` (silnik zapasowy).
- **TTS narzeka na silnik** → w zakładce **Mowa (TTS)** jest status na dole: pokaże,
  którego silnika używa (Windows / espeak-ng / pyttsx3) i ile głosów znalazł.
- **Wkleiłem klucz, a mowa i tak idzie z systemu** → w zakładce **Prywatność** trzeba
  zaznaczyć **zgodę** „Zgadzam się wysłać treść tekstu” (bez tego aplikacja nie pyta chmury)
  i sprawdzić, czy adres to `https://…` albo `http://localhost:…`
- **Chmura 401 / „klucz odrzucony”** → kontrolka „Testuj połączenie” pokaże, czy klucz
  działa i czy model jest na liście; aplikacja i tak nie przerwie pracy — przesiądzie się
  na silnik lokalny (komunikat w logi)
- **AI Wideo nie chce zmienić planu** → status w wierszu **🌐 Zapytaj AI o plan** mówi czemu
  (brak zgody na prompt / brak klucza / miniatury wyłączone). Odpowiedź bez liczb z listy
  pola jest odrzucana — to celowe
- **Mp4 tnie się / nie reaguje na suwak** → niektóre kodeki wolno wykonują seek: aplikacja
  sama przewija odczytując klatki (do ~3000). Dla najpłynniejszej projekcji używaj H.264 MP4.
- **Po powtórce widać skok obrazu** → podnieś **„Płynny szew”** (suwak pod podglądem)
  na 0,4–0,8 s. Ustawienie 0 s = twarde cięcie (jak było wcześniej).
- **Render długi** → 10 s filmu to ok. 5 s (720p) / 11 s (1080p); można **Anulować**
  w każdej chwili, a w trakcie renderu korzystać z aplikacji.
- **AI nie łapie mojego stylu** → dopisz konkret: tempo („wolno”, „szybkie cięcia”),
  look („sepia”, „czarno-białe”, „mroczny”), ruch („najazd”, „panorama”, „stabilna kamera”),
  długość („20 sekund”) i liczbę cięć („cięcia co 2 sekundy”).

## 📜 Licencja
Projekt własny, do użytku osobistego. Unity Capture i VB-CABLE mają własne licencje.
