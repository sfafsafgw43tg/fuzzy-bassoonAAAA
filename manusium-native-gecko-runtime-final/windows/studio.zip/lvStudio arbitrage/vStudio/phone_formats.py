# -*- coding: utf-8 -*-
"""
Realme 12 Pro Studio — formaty telefonowe (pionowe, jak z aparatu w telefonie).

Realme 12 Pro (prawdziwe dane): ekran 6.7" AMOLED 1080 x 2412 px, proporcje 20:9,
aparat 50+8+32 MP, wideo 4K 3840x2160 / 1080p.
"""
from collections import OrderedDict

PHONE_FORMATS = OrderedDict([
    ("webcam_safe", {
        "label": "USB webcam safe  •  1280 × 720  (16:9)",
        "width": 1280, "height": 720, "desc": "Safe DirectShow/Unity Capture output for Android Emulator and video-call apps.",
    }),
    ("realme12pro", {
        "label": "Realme 12 Pro  •  1080 × 2412  (20:9, natywny)",
        "width": 1080, "height": 2412, "desc": "Natywna rozdzielczość ekranu Realme 12 Pro.",
    }),
    ("fhd_vert", {
        "label": "Full HD pion  •  1080 × 1920  (9:16)",
        "width": 1080, "height": 1920, "desc": "Klasyczny pionowy Full HD — TikTok / Reels / rozmowy.",
    }),
    ("hd_vert", {
        "label": "HD pion  •  720 × 1600  (20:9, lekki)",
        "width": 720, "height": 1600, "desc": "Lżejszy format — słabsze komputery, mniejsze opóźnienia.",
    }),
    ("qhd_vert", {
        "label": "QHD pion  •  1440 × 2560  (9:16)",
        "width": 1440, "height": 2560, "desc": "Ostrzejszy obraz, większe obciążenie.",
    }),
    ("uhd_vert", {
        "label": "4K pion  •  2160 × 3840  (9:16)",
        "width": 2160, "height": 3840, "desc": "Maksymalna jakość. Uwaga: wymaga mocnego PC.",
    }),
    ("fhd_horiz", {
        "label": "Full HD poziom  •  1920 × 1080  (16:9)",
        "width": 1920, "height": 1080, "desc": "Poziomo — Zoom / Teams / Meet na komputerze.",
    }),
    ("square", {
        "label": "Kwadrat  •  1080 × 1080  (1:1)",
        "width": 1080, "height": 1080, "desc": "Instagram / awatar / zdjęcia profilowe.",
    }),
    ("story", {
        "label": "Story  •  1080 × 2400  (pełny ekran)",
        "width": 1080, "height": 2400, "desc": "Pełnoekranowe stories.",
    }),
])

FIT_MODES = OrderedDict([
    ("fill",   "Wypełnij (przytnij brzegi)"),
    ("fit",    "Dopasuj (czarne pasy)"),
    ("stretch", "Rozciągnij (cały kadr)"),
    ("blur",   "Dopasuj + rozmyte tło"),
])

FILTERS = OrderedDict([
    ("normal", "Normalny"),
    ("vivid",  "Żywy (Realme Vivid)"),
    ("night",  "Nocny"),
    ("bw",     "Czarno-biały"),
    ("sepia",  "Sepia / Retro"),
    ("cold",   "Chłodny"),
    ("warm",   "Ciepły"),
])

TRANSITIONS = OrderedDict([
    ("none",  "Brak (cięcie)"),
    ("fade",  "Przenikanie"),
    ("black", "Przez czerń"),
])

SLIDESHOW_MODES = OrderedDict([
    ("manual", "Ręczny (strzałki / przyciski)"),
    ("auto",   "Auto — po kolei"),
    ("random", "Auto — losowo"),
])


def get_format(format_id: str):
    return PHONE_FORMATS.get(format_id, PHONE_FORMATS["realme12pro"])
