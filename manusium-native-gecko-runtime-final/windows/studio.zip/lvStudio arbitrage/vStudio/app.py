# -*- coding: utf-8 -*-
"""
Realme 12 Pro Studio  •  v1.3  •  minimalistyczny czarno-biały UI (os czasu audio + AI wideo)
Wirtualna kamera Unity Capture + mikrofon VB-CABLE  •  100% OFFLINE.
Start (Windows): dwuklik START_REALME_CAM.bat
"""
import json
import os
import sys
import threading
import time
import traceback
import webbrowser
from datetime import datetime

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)
os.chdir(APP_DIR)

CONFIG_PATH = os.path.join(APP_DIR, "config.json")

DEFAULT_CONFIG = {
    "mode": "android",
    "android_only": True,
    "targets": ["android-emulator"],
    "outputs": {"android": True, "desktop": False, "browser": False, "obs_scene": False},
    "device_names": {"camera": "Unity Capture virtual camera", "microphone": "CABLE Output (VB-Audio Virtual Cable)"},
    "video": {
        "format_id": "webcam_safe", "fit_mode": "fill", "filter": "normal",
        "fps": 30, "backend": "unitycapture",
        "slideshow_mode": "auto", "slideshow_interval": 6.0,
        "transition": "fade", "effect_shake": False, "effect_shake_amount": 4.0,
        "effect_grain": False, "effect_grain_amount": 6.0,
        "effect_vignette": False, "effect_autofocus": False,
        "overlay_rec": True, "overlay_timestamp": True,
        "overlay_brand": True, "overlay_battery": True,
        "mirror": False, "rotate": 0,
        "zoom": 1.0, "pan_x": 0.0, "pan_y": 0.0,
        "orientation": "portrait", "frames": {},
        "loop_video": True, "loop_blend": 0.35,
    },
    "audio": {
        "profile": "pokoj", "volume": 0.8, "noise_level": 0.5,
        "event_rate": 0.5, "bass": 0.5, "sample_rate": 48000,
        "monitor_locally": False, "auto_random_profile": False,
        "breath_on": True, "breath_level": 0.45, "breath_rate": 13,
        "output_device_name": "", "cable_only": True,
        "music_gain": 0.9, "music_loop": False, "music_files": [],
        "monitor_on": False, "monitor_device_name": "", "monitor_gain": 0.8,
        "record_folder": "",
    },
    "ai": {"prompt": "", "photos": [], "quality": "1080p", "music_name": ""},
    "tts": {"text": "", "voice": "", "rate": 0, "volume": 90},
    # klucze API — DOMYŚLNIE offline (patrz cloud_net.DEFAULTS; trzymamy je
    # tylko w config.json, nigdy w presetach ani w dzienniku)
    "net": {
        "provider": "offline", "base_url": "https://api.openai.com/v1",
        "key_tts": "", "key_ai": "",
        "tts_model": "gpt-4o-mini-tts", "tts_voice": "alloy", "ai_model": "gpt-4o-mini",
        "consent_tts": False, "consent_ai": False, "ai_send_photos": False,
        "ai_thumb_px": 384, "remember_keys": True, "timeout_s": 30,
    },
    "ui": {"theme": "dark", "language": "pl", "autosave": True},
}


def load_config():
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    try:
        if os.path.isfile(CONFIG_PATH):
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                user = json.load(f)
            # scalamy kazda sekcje opisana w DEFAULT_CONFIG (w tym "ai" —
            # dawniej pomijana, przez co ustawienia zakladki AI Wideo
            # zapisywane przy zamknieciu przepadaly przy nastepnym starcie)
            for section, defaults in DEFAULT_CONFIG.items():
                if isinstance(defaults, dict) and isinstance(user.get(section), dict):
                    cfg.setdefault(section, {}).update(user[section])
    except Exception:
        pass
    return cfg


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


CFG = load_config()

try:
    from phone_formats import PHONE_FORMATS, FIT_MODES, FILTERS, TRANSITIONS, SLIDESHOW_MODES
except Exception:
    PHONE_FORMATS, FIT_MODES, FILTERS, TRANSITIONS, SLIDESHOW_MODES = {}, {}, {}, {}, {}

try:
    from audio_engine import PhoneNoiseEngine, AUDIO_PROFILES
    HAS_AUDIO = True
except Exception:
    HAS_AUDIO = False
    PhoneNoiseEngine, AUDIO_PROFILES = None, {}

try:
    from video_engine import VideoEngine
    HAS_VIDEO = True
except Exception:
    HAS_VIDEO = False
    VideoEngine = None

try:
    from ui_v13 import V13Mixin, HAS_TIMELINE, HAS_AI
except Exception:
    HAS_TIMELINE = HAS_AI = False
    class V13Mixin(object):
        def _init_v13(self): pass
        def _v13_on_close(self): pass
        def _v13_shutdown(self): pass
        def _v13_restore_music(self): pass
        def _v13_bind_keys(self): pass
        def _v13_tick(self): pass
        def _tab_music(self, tab): pass
        def _tab_ai(self, tab): pass

try:
    from ui_v14 import V14Mixin, HAS_TTS
    HAS_V14 = True
except Exception:
    HAS_TTS = HAS_V14 = False
    class V14Mixin(object):
        def _init_v14(self): pass
        def _build_v14_ui(self): pass
        def _v14_tick(self, force=False): pass
        def _v14_bind_keys(self): pass
        def _v14_on_close(self): pass
        def _tab_tts(self, tab): pass
        def _tab_net(self, tab): pass
        def _open_settings_window(self): pass
        def _open_privacy_info(self): pass

        def _net_scrub(self, msg):
            return msg


try:
    import cloud_net as NET
    HAS_NET = True
except Exception:
    HAS_NET = False
    NET = None

try:
    import virtual_devices as VD
    HAS_VD = True
except Exception:
    HAS_VD = False
    VD = None

try:
    import customtkinter as ctk
    from tkinter import filedialog, messagebox
    HAS_CTK = True
except Exception as e:
    print("BLAD: brak biblioteki customtkinter. Uruchom INSTALUJ.bat")
    print(e)
    sys.exit(1)

try:
    from PIL import Image
    HAS_PIL = True
except Exception:
    HAS_PIL = False
    Image = None

# --- monochromatyczna paleta ---
BG     = "#0B0D12"
CARD   = "#141821"
CARD2  = "#1B212E"
LINE   = "#262E40"
MUTED  = "#8B93A5"
TEXT   = "#E9EBF1"
DIM    = "#5A6272"
WHITE  = "#F2F3F6"
WHITE_HOVER = "#C9CDD6"
GHOST = dict(fg_color="transparent", border_width=1, border_color="#262E40",
             text_color="#E9EBF1", corner_radius=10, hover_color="#1B212E")
PRIMARY = dict(fg_color="#F2F3F6", text_color="black", hover_color="#C9CDD6",
               corner_radius=10)

BACKEND_LABELS = {"unitycapture": "Unity Capture (virtual)"}

ctk.set_appearance_mode("dark")
_theme = os.path.join(APP_DIR, "assets", "theme_mono.json")
try:
    if os.path.isfile(_theme):
        ctk.set_default_color_theme(_theme)
    else:
        ctk.set_default_color_theme("green")
except Exception:
    ctk.set_default_color_theme("green")


# ================================================================== APLIKACJA
class RealmeStudioApp(V14Mixin, V13Mixin, ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Realme 12 Pro Studio  •  OFFLINE")
        self.geometry("1440x920")
        self.minsize(1280, 820)
        self.configure(fg_color=BG)

        self.CFG = CFG          # wspolny slownik konfiguracji (dla ui_v13)
        self.audio = PhoneNoiseEngine(sample_rate=CFG["audio"].get("sample_rate", 48000)) if HAS_AUDIO else None
        self.video = VideoEngine() if HAS_VIDEO else None
        self.broadcasting = False
        self._closing = False
        self._sel_idx = 0
        self._dev_map = {"(domyślne)": None}

        if self.audio:
            a = CFG["audio"]
            self.audio.set_profile(a.get("profile", "pokoj"))
            self.audio.set_volume(a.get("volume", 0.8))
            self.audio.set_noise_level(a.get("noise_level", 0.5))
            self.audio.set_event_rate(a.get("event_rate", 0.5))
            self.audio.set_bass(a.get("bass", 0.5))
            self.audio.set_breath(a.get("breath_on", True))
            self.audio.set_breath_level(a.get("breath_level", 0.45))
            self.audio.set_breath_rate(a.get("breath_rate", 13))

        if self.video:
            v = CFG["video"]
            self.video.format_id = v.get("format_id", "realme12pro")
            self.video.fit_mode = v.get("fit_mode", "fill")
            self.video.filter_id = v.get("filter", "normal")
            self.video.fps = int(v.get("fps", 30))
            self.video.vcam_backend = "unitycapture"  # fixed: this app uses Unity Capture only
            self.video.mode = v.get("slideshow_mode", "auto")
            self.video.interval = float(v.get("slideshow_interval", 6.0))
            self.video.transition = v.get("transition", "fade")
            self.video.fx_shake = bool(v.get("effect_shake", True))
            self.video.fx_shake_amount = float(v.get("effect_shake_amount", 4.0))
            self.video.fx_grain = bool(v.get("effect_grain", True))
            self.video.fx_grain_amount = float(v.get("effect_grain_amount", 6.0))
            self.video.fx_vignette = bool(v.get("effect_vignette", True))
            self.video.fx_autofocus = bool(v.get("effect_autofocus", True))
            self.video.ov_rec = bool(v.get("overlay_rec", True))
            self.video.ov_timestamp = bool(v.get("overlay_timestamp", True))
            self.video.ov_brand = bool(v.get("overlay_brand", True))
            self.video.ov_battery = bool(v.get("overlay_battery", True))
            self.video.mirror = bool(v.get("mirror", False))
            self.video.rotate = int(v.get("rotate", 0))
            self.video.zoom = float(v.get("zoom", 1.0))
            self.video.pan_x = float(v.get("pan_x", 0.0))
            self.video.pan_y = float(v.get("pan_y", 0.0))
            self.video.orientation = v.get("orientation", "portrait")
            try:
                self.video.frame_memory = dict(v.get("frames", {}) or {})
            except Exception:
                pass
            self.video.on_slide_change = self._on_slide_change
            try:
                media_dir = os.path.join(APP_DIR, "media")
                if os.path.isdir(media_dir):
                    self.video.add_folder(media_dir)
            except Exception:
                pass
            self.video.start()

        self._init_v13()
        self._init_v14()
        self._build_ui()
        self._refresh_devices_combo()
        self._refresh_playlist_ui()
        self._sync_frame_ui()
        self._tick_preview()
        self._tick_meters()
        self._log("Witaj w Realme 12 Pro Studio.")
        self._log("1) Dodaj zdjęcia / nagrania   2) Ustaw kadr i dźwięk   3) Start nadawania.")
        self._log("4) Zakładka Audio: muzyka na osi czasu, odsłuch u siebie, nagrywanie WAV.")
        self._log("5) Zakładka AI Wideo: napisz prompt — AI zrobi film ze zdjęć (offline).")
        self._log("6) Pod podglądem: ⏯ start/pauza/stop nagrania, suwak czasu, pętla z płynnym szwem.")
        if HAS_TTS:
            self._log("7) Zakładka Mowa (TTS): tekst → głos, leci do mikrofonu. Offline.")
        else:
            self._log("7) Uwaga: brak modułu ui_v14.py (TTS / ustawienia / pasek odtwarzacza).")
        if self.video and self.video.playlist:
            self._log("Wczytano %d plików z folderu media/." % len(self.video.playlist))
        if self.audio and self.audio.demo_mode:
            self._log("Uwaga: brak modułu audio (sounddevice) — tryb demo. Uruchom INSTALUJ.bat.")
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.bind("<Left>", lambda e: self._slide_prev())
        self.bind("<Right>", lambda e: self._slide_next())
        self._v13_bind_keys()
        self._v14_bind_keys()
        self.after(400, self._v13_restore_music)

    # ---------------------------------------------------------- pomocnicze
    def _label_of(self, mapping, key):
        try:
            return mapping.get(key, next(iter(mapping.values())))
        except Exception:
            return "-"

    def _key_of(self, mapping, label):
        for k, v in mapping.items():
            if v == label:
                return k
        return next(iter(mapping.keys()), "")

    def _section(self, parent, text):
        ctk.CTkLabel(parent, text=text.upper(), font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(16, 4))

    def _hint(self, parent, text):
        ctk.CTkLabel(parent, text=text, font=ctk.CTkFont(size=11),
                     text_color=MUTED, wraplength=280, justify="left").pack(
                         anchor="w", padx=16, pady=(2, 4))

    def _slider_card(self, parent, label, value, frm, to, steps, fmt, cmd):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="x", padx=16, pady=(10, 0))
        ctk.CTkLabel(box, text=label, font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        val = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT)
        val.pack(side="right")
        s = ctk.CTkSlider(parent, from_=frm, to=to, number_of_steps=steps,
                          command=lambda v: (val.configure(text=fmt(float(v))), cmd()))
        s.pack(fill="x", padx=16, pady=(4, 2))
        s.set(value)
        val.configure(text=fmt(float(value)))
        return s, val

    def _status_pill(self, parent, col):
        pill = ctk.CTkFrame(parent, fg_color=CARD2, corner_radius=18,
                            border_width=1, border_color=LINE)
        pill.grid(row=0, column=col, padx=6, pady=10, sticky="w")
        dot = ctk.CTkLabel(pill, text="●", font=ctk.CTkFont(size=11),
                           text_color=DIM, width=14)
        dot.pack(side="left", padx=(12, 2), pady=7)
        txt = ctk.CTkLabel(pill, text="", font=ctk.CTkFont(size=12, weight="bold"),
                           text_color=TEXT)
        txt.pack(side="left", padx=(2, 12), pady=7)
        return pill, dot, txt

    def _log(self, msg):
        try:
            ts = datetime.now().strftime("%H:%M:%S")
            msg = self._net_scrub(msg)     # klucz API nigdy nie trafi do dziennika
            self.txt_log.insert("end", "[%s] %s\n" % (ts, msg))
            self.txt_log.see("end")
        except Exception:
            print(msg)

    # ------------------------------------------------------------- budowa UI
    def _build_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ===== pasek górny =====
        top = ctk.CTkFrame(self, corner_radius=0, fg_color=CARD)
        top.grid(row=0, column=0, columnspan=3, sticky="ew")
        top.grid_columnconfigure(4, weight=1)

        brand = ctk.CTkFrame(top, fg_color="transparent")
        brand.grid(row=0, column=0, padx=20, pady=12, sticky="w")
        ctk.CTkLabel(brand, text="Realme 12 Pro Studio",
                     font=ctk.CTkFont(size=17, weight="bold"), text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(brand, text="WIRTUALNA KAMERA  •  MIKROFON  •  OFFLINE",
                     font=ctk.CTkFont(size=10), text_color=MUTED).pack(anchor="w")

        _, self.dot_cam, self.led_cam = self._status_pill(top, 2)
        _, self.dot_mic, self.led_mic = self._status_pill(top, 3)

        self.btn_broadcast = ctk.CTkButton(top, text="▶   Start nadawania",
                                           font=ctk.CTkFont(size=13, weight="bold"),
                                           width=210, height=42, command=self._toggle_broadcast,
                                           **PRIMARY)
        self.btn_broadcast.grid(row=0, column=5, padx=6, pady=10)
        ctk.CTkButton(top, text="Urządzenia", width=120, height=42,
                      command=self._open_devices_window, **GHOST).grid(row=0, column=6, padx=6, pady=10)
        ctk.CTkButton(top, text="Pomoc", width=96, height=42,
                      command=self._open_help_window, **GHOST).grid(row=0, column=7, padx=(6, 6), pady=10)
        ctk.CTkButton(top, text="⚙ Ustawienia", width=124, height=42,
                      command=self._open_settings_window, **GHOST).grid(row=0, column=8, padx=(6, 18), pady=10)

        # ===== lewa kolumna: biblioteka =====
        left = ctk.CTkFrame(self, width=300, fg_color=CARD, corner_radius=16,
                            border_width=1, border_color=LINE)
        left.grid(row=1, column=0, sticky="nsew", padx=(14, 7), pady=14)
        left.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(left, text="Biblioteka", font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=TEXT).grid(row=0, column=0, padx=16, pady=(14, 6), sticky="w")

        btns = ctk.CTkFrame(left, fg_color="transparent")
        btns.grid(row=1, column=0, sticky="ew", padx=12)
        ctk.CTkButton(btns, text="+ Dodaj", width=120, command=self._add_files,
                      **PRIMARY).grid(row=0, column=0, padx=4, pady=4)
        ctk.CTkButton(btns, text="Folder", width=120, command=self._add_folder,
                      **GHOST).grid(row=0, column=1, padx=4, pady=4)

        self.playlist_box = ctk.CTkScrollableFrame(left, label_text="", fg_color=CARD2, corner_radius=12)
        self.playlist_box.grid(row=2, column=0, sticky="nsew", padx=12, pady=6)

        nav = ctk.CTkFrame(left, fg_color="transparent")
        nav.grid(row=3, column=0, sticky="ew", padx=12, pady=(2, 4))
        nav.grid_columnconfigure(0, weight=1)
        nav.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(nav, text="◀  Poprzednie", command=self._slide_prev,
                      **GHOST).grid(row=0, column=0, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(nav, text="Następne  ▶", command=self._slide_next,
                      **GHOST).grid(row=0, column=1, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(nav, text="Usuń zaznaczony", command=self._remove_selected,
                      **GHOST).grid(row=1, column=0, padx=4, pady=4, sticky="ew")
        mv = ctk.CTkFrame(nav, fg_color="transparent")
        mv.grid(row=1, column=1, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(mv, text="▲", width=52, command=lambda: self._move_sel(-1),
                      **GHOST).pack(side="left", expand=True, fill="x", padx=(0, 4))
        ctk.CTkButton(mv, text="▼", width=52, command=lambda: self._move_sel(1),
                      **GHOST).pack(side="left", expand=True, fill="x", padx=(4, 0))
        ctk.CTkButton(nav, text="Wyczyść listę", command=self._clear_playlist,
                      **GHOST).grid(row=2, column=0, columnspan=2, padx=4, pady=(4, 12), sticky="ew")

        # ===== środek: podgląd =====
        mid = ctk.CTkFrame(self, fg_color=CARD, corner_radius=16,
                           border_width=1, border_color=LINE)
        mid.grid(row=1, column=1, sticky="nsew", padx=7, pady=14)
        mid.grid_columnconfigure(0, weight=1)
        mid.grid_rowconfigure(1, weight=1)

        mid_top = ctk.CTkFrame(mid, fg_color="transparent")
        mid_top.grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 6))
        ctk.CTkLabel(mid_top, text="Podgląd", font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=TEXT).pack(side="left")
        self.lbl_fps = ctk.CTkLabel(mid_top, text="", font=ctk.CTkFont(size=12), text_color=MUTED)
        self.lbl_fps.pack(side="right")
        self.lbl_slide = ctk.CTkLabel(mid_top, text="", font=ctk.CTkFont(size=12), text_color=MUTED)
        self.lbl_slide.pack(side="right", padx=12)

        phone_outer = ctk.CTkFrame(mid, fg_color="#07080B", border_width=2,
                                   border_color=LINE, corner_radius=28)
        phone_outer.grid(row=1, column=0, sticky="nsew", padx=24, pady=4)
        phone_outer.grid_columnconfigure(0, weight=1)
        phone_outer.grid_rowconfigure(1, weight=1)
        notch = ctk.CTkFrame(phone_outer, fg_color="#07080B", height=20)
        notch.grid(row=0, column=0, sticky="ew", padx=70, pady=(8, 0))
        ctk.CTkLabel(notch, text="●", text_color="#1E232E",
                     font=ctk.CTkFont(size=13)).pack()
        self.lbl_preview = ctk.CTkLabel(phone_outer, text="Dodaj zdjęcia lub nagrania",
                                        font=ctk.CTkFont(size=13), text_color=MUTED)
        self.lbl_preview.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 12))
        self._drag_last = None
        self.lbl_preview.bind("<ButtonPress-1>", self._frame_drag_start)
        self.lbl_preview.bind("<B1-Motion>", self._frame_drag_move)
        self.lbl_preview.bind("<ButtonRelease-1>", lambda e: setattr(self, "_drag_last", None))
        self.lbl_preview.bind("<Double-Button-1>", lambda e: self._frame_reset())
        self.lbl_preview.bind("<MouseWheel>", self._frame_wheel)
        self.lbl_preview.bind("<Button-4>", lambda e: self._frame_zoom_step(1.1))
        self.lbl_preview.bind("<Button-5>", lambda e: self._frame_zoom_step(1 / 1.1))

        # pasek pod podglądem: format + orientacja + silnik + fps
        bar = ctk.CTkFrame(mid, fg_color=CARD2, corner_radius=12)
        bar.grid(row=2, column=0, sticky="ew", padx=16, pady=12)
        bar.grid_columnconfigure(0, weight=1)
        bar.grid_columnconfigure(1, weight=0)
        fmt_labels = [v["label"] for v in PHONE_FORMATS.values()] or ["-"]
        cur_fmt = PHONE_FORMATS.get(self.video.format_id, {}).get("label", fmt_labels[0]) if self.video else fmt_labels[0]
        self.var_format = ctk.StringVar(value=cur_fmt)
        ctk.CTkOptionMenu(bar, variable=self.var_format, values=fmt_labels,
                          command=self._on_format_change).grid(row=0, column=0, padx=10, pady=8, sticky="ew")
        self.var_orient = ctk.StringVar(value="Pionowo")
        ctk.CTkSegmentedButton(bar, values=["Pionowo", "Poziomo"],
                               variable=self.var_orient,
                               command=self._on_orient_seg).grid(row=0, column=1, padx=(0, 10), pady=8)
        be_row = ctk.CTkFrame(bar, fg_color="transparent")
        be_row.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 8))
        ctk.CTkLabel(be_row, text="Silnik:", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        be_init = BACKEND_LABELS.get(self.video.vcam_backend, "Auto") if self.video else "Auto"
        self.var_backend = ctk.StringVar(value=be_init)
        ctk.CTkSegmentedButton(be_row, values=list(BACKEND_LABELS.values()),
                               variable=self.var_backend,
                               command=self._on_backend_change).pack(side="left", padx=(6, 16))
        ctk.CTkLabel(be_row, text="FPS:", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        self.var_fps = ctk.StringVar(value=str(self.video.fps if self.video else 30))
        ctk.CTkSegmentedButton(be_row, values=["24", "30", "60"],
                               variable=self.var_fps,
                               command=self._on_fps_change).pack(side="left", padx=6)
        self.lbl_camstatus = ctk.CTkLabel(be_row, text="", font=ctk.CTkFont(size=11), text_color=MUTED)
        self.lbl_camstatus.pack(side="right")
        self._update_orient_btn()

        # ===== prawa kolumna: zakładki =====
        right = ctk.CTkFrame(self, width=340, fg_color=CARD, corner_radius=16,
                             border_width=1, border_color=LINE)
        right.grid(row=1, column=2, sticky="nsew", padx=(7, 14), pady=14)
        self.tabs = ctk.CTkTabview(right, fg_color=CARD, corner_radius=12)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=8)
        tab_names = ["Dźwięk", "Audio"] + (["Mowa (TTS)"] if HAS_V14 else []) + \
                    ["AI Wideo"] + (["Prywatność"] if HAS_V14 else []) + \
                    ["Obraz", "Kadr", "Efekty"]
        for name in tab_names:
            self.tabs.add(name)
        self._tab_sound(self.tabs.tab("Dźwięk"))
        self._tab_music(self.tabs.tab("Audio"))
        if "Mowa (TTS)" in tab_names:
            self._tab_tts(self.tabs.tab("Mowa (TTS)"))
        self._tab_ai(self.tabs.tab("AI Wideo"))
        if "Prywatność" in tab_names:
            self._tab_net(self.tabs.tab("Prywatność"))
        self._tab_image(self.tabs.tab("Obraz"))
        self._tab_frame(self.tabs.tab("Kadr"))
        self._tab_fx(self.tabs.tab("Efekty"))
        self._build_v14_ui()          # pasek odtwarzacza pod podglądem

        # ===== dół: dziennik =====
        bottom = ctk.CTkFrame(self, height=96, fg_color=CARD, corner_radius=16,
                              border_width=1, border_color=LINE)
        bottom.grid(row=2, column=0, columnspan=3, sticky="ew", padx=14, pady=(0, 14))
        bottom.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(bottom, text="Dziennik", font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=MUTED).grid(row=0, column=0, padx=14, pady=(6, 0), sticky="w")
        self.txt_log = ctk.CTkTextbox(bottom, height=52, font=ctk.CTkFont(size=11),
                                      fg_color=CARD2, corner_radius=10, border_width=0,
                                      text_color=TEXT)
        self.txt_log.grid(row=1, column=0, sticky="ew", padx=14, pady=(2, 10))

    def _scroll_tab(self, tab):
        box = ctk.CTkScrollableFrame(tab, label_text="", fg_color=CARD)
        box.pack(fill="both", expand=True)
        return box

    # ------------------------------------------------- zakładka: DŹWIĘK
    def _tab_sound(self, tab):
        box = self._scroll_tab(tab)
        self.lbl_audio_warn = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11, weight="bold"),
                                           text_color=WHITE, wraplength=280, justify="left")
        self.lbl_audio_warn.pack(anchor="w", padx=16, pady=(12, 0))

        self._section(box, "Sceneria")
        self.var_profile = ctk.StringVar(value=(self.audio.profile_id if self.audio else "pokoj"))
        for pid, p in AUDIO_PROFILES.items():
            label = p["label"]
            ctk.CTkRadioButton(box, text=label, variable=self.var_profile, value=pid,
                               command=self._on_profile).pack(anchor="w", padx=16, pady=2)
        self.lbl_prof_desc = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                          text_color=MUTED, wraplength=280, justify="left")
        self.lbl_prof_desc.pack(anchor="w", padx=16, pady=(4, 0))

        self._section(box, "Poziomy")
        pct = lambda v: "%d%%" % int(v * 100)
        a = CFG["audio"]
        self.sld_volume, self.val_volume = self._slider_card(
            box, "Głośność", a.get("volume", 0.8), 0, 1, 100, pct, self._on_audio_sliders)
        self.sld_noise, self.val_noise = self._slider_card(
            box, "Poziom szumu", a.get("noise_level", 0.5), 0, 1, 100, pct, self._on_audio_sliders)
        self.sld_event, self.val_event = self._slider_card(
            box, "Częstotliwość zdarzeń", a.get("event_rate", 0.5), 0, 1, 100, pct, self._on_audio_sliders)
        self.sld_bass, self.val_bass = self._slider_card(
            box, "Niskie tony", a.get("bass", 0.5), 0, 1, 100, pct, self._on_audio_sliders)

        self._section(box, "Oddech")
        self.var_breath = ctk.BooleanVar(value=a.get("breath_on", True))
        ctk.CTkCheckBox(box, text="Oddech (odznacz = wyciszony)", variable=self.var_breath,
                        command=self._on_breath_toggle).pack(anchor="w", padx=16, pady=2)
        self.sld_breath, self.val_breath = self._slider_card(
            box, "Głębokość oddechu", a.get("breath_level", 0.45), 0, 1, 100, pct, self._on_breath_level)
        self.sld_brate, self.val_brate = self._slider_card(
            box, "Tempo oddechu", a.get("breath_rate", 13), 6, 24, 18,
            lambda v: "%d /min" % int(v), self._on_breath_rate)
        self._hint(box, "Cichy, naturalny oddech jak z telefonu blisko ust. Tempo dryfuje ±3.")

        self._section(box, "Mikrofon")
        self.var_mute = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(box, text="Wycisz mikrofon", variable=self.var_mute,
                        command=self._on_mute).pack(anchor="w", padx=16, pady=2)
        ctk.CTkLabel(box, text="Urządzenie wyjściowe", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(10, 0))
        self.var_outdev = ctk.StringVar(value="(domyślne)")
        self.opt_outdev = ctk.CTkOptionMenu(box, variable=self.var_outdev, values=["(domyślne)"],
                                            width=270, command=lambda _: self._on_outdev_change())
        self.opt_outdev.pack(anchor="w", padx=16, pady=4)
        self.var_cable_only = ctk.BooleanVar(value=a.get("cable_only", True))
        ctk.CTkCheckBox(box, text="Tylko wirtualne kable (bezpieczne)", variable=self.var_cable_only,
                        command=self._refresh_devices_combo).pack(anchor="w", padx=16, pady=2)
        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(row, text="Odśwież", width=130, command=self._refresh_devices_combo,
                      **GHOST).pack(side="left", padx=4)
        ctk.CTkButton(row, text="Test dźwięku", width=130, command=self._test_sound,
                      **GHOST).pack(side="left", padx=4)
        self.lbl_outdev = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                       text_color=MUTED, wraplength=280, justify="left")
        self.lbl_outdev.pack(anchor="w", padx=16, pady=(4, 0))
        ctk.CTkLabel(box, text="Poziom (VU)", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(10, 0))
        self.vu_bar = ctk.CTkProgressBar(box, height=14, corner_radius=7,
                                         fg_color=CARD2, progress_color=WHITE)
        self.vu_bar.pack(fill="x", padx=16, pady=4)
        self.vu_bar.set(0)
        self._hint(box, "W komunikatorze jako mikrofon wybierz CABLE Output (VB-Audio Virtual Cable).")
        self._update_profile_desc()

    # ------------------------------------------------- zakładka: OBRAZ
    def _tab_image(self, tab):
        box = self._scroll_tab(tab)
        v = self.video
        self._section(box, "Kadr i filtr")
        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=2)
        ctk.CTkLabel(row, text="Kadrowanie", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_fit = ctk.StringVar(value=self._label_of(FIT_MODES, v.fit_mode if v else "fill"))
        ctk.CTkOptionMenu(row, variable=self.var_fit, values=list(FIT_MODES.values()) or ["-"],
                          width=170, command=self._on_fit_change).pack(side="right")
        row2 = ctk.CTkFrame(box, fg_color="transparent")
        row2.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(row2, text="Filtr aparatu", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_filter = ctk.StringVar(value=self._label_of(FILTERS, v.filter_id if v else "normal"))
        ctk.CTkOptionMenu(row2, variable=self.var_filter, values=list(FILTERS.values()) or ["-"],
                          width=170, command=self._on_filter_change).pack(side="right")
        row3 = ctk.CTkFrame(box, fg_color="transparent")
        row3.pack(fill="x", padx=16, pady=6)
        ctk.CTkButton(row3, text="Obrót 90°", width=120, command=self._rotate,
                      **GHOST).pack(side="left")
        self.var_mirror = ctk.BooleanVar(value=v.mirror if v else False)
        ctk.CTkCheckBox(row3, text="Lustro", variable=self.var_mirror,
                        command=self._on_mirror).pack(side="right", padx=4)

        self._section(box, "Pokaz slajdów")
        row4 = ctk.CTkFrame(box, fg_color="transparent")
        row4.pack(fill="x", padx=16, pady=2)
        ctk.CTkLabel(row4, text="Tryb", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        self.var_mode = ctk.StringVar(value=self._label_of(SLIDESHOW_MODES, v.mode if v else "auto"))
        ctk.CTkOptionMenu(row4, variable=self.var_mode, values=list(SLIDESHOW_MODES.values()) or ["-"],
                          width=170, command=self._on_mode_change).pack(side="right")
        row5 = ctk.CTkFrame(box, fg_color="transparent")
        row5.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(row5, text="Co ile sekund", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_interval = ctk.StringVar(value=str(v.interval if v else 6.0))
        ctk.CTkOptionMenu(row5, variable=self.var_interval, width=100,
                          values=["2", "3", "4", "5", "6", "8", "10", "15", "20", "30"],
                          command=self._on_interval_change).pack(side="right")
        row6 = ctk.CTkFrame(box, fg_color="transparent")
        row6.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(row6, text="Przejście", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        self.var_trans = ctk.StringVar(value=self._label_of(TRANSITIONS, v.transition if v else "fade"))
        ctk.CTkOptionMenu(row6, variable=self.var_trans, values=list(TRANSITIONS.values()) or ["-"],
                          width=170, command=self._on_trans_change).pack(side="right")

        self._section(box, "Nakładki aparatu")
        self.var_rec = ctk.BooleanVar(value=v.ov_rec if v else True)
        self.var_ts = ctk.BooleanVar(value=v.ov_timestamp if v else True)
        self.var_brand = ctk.BooleanVar(value=v.ov_brand if v else True)
        self.var_batt = ctk.BooleanVar(value=v.ov_battery if v else True)
        for text, var in (("Wskaźnik REC", self.var_rec), ("Data i godzina", self.var_ts),
                          ("Podpis Realme", self.var_brand), ("Ikona baterii", self.var_batt)):
            ctk.CTkCheckBox(box, text=text, variable=var,
                            command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self._hint(box, "Skróty: strzałki ← → przełączają slajdy.")

    # ------------------------------------------------- zakładka: KADR
    def _tab_frame(self, tab):
        box = self._scroll_tab(tab)
        v = self.video
        self._section(box, "Ręczne kadrowanie")
        self._hint(box, "Chwyć zdjęcie na podglądzie i przeciągnij. "
                        "Kółko myszy = zoom. Podwójny klik = reset. "
                        "Każde zdjęcie pamięta własny kadr.")
        self.sld_zoom, self.val_zoom = self._slider_card(
            box, "Zoom", v.zoom if v else 1.0, 0.5, 3.0, 50,
            lambda x: "%.2f×" % x, self._on_frame_sliders)
        self.sld_panx, self.val_panx = self._slider_card(
            box, "Pozycja X", v.pan_x if v else 0.0, -1, 1, 100,
            lambda x: "%+.2f" % x, self._on_frame_sliders)
        self.sld_pany, self.val_pany = self._slider_card(
            box, "Pozycja Y", v.pan_y if v else 0.0, -1, 1, 100,
            lambda x: "%+.2f" % x, self._on_frame_sliders)
        grid = ctk.CTkFrame(box, fg_color="transparent")
        grid.pack(fill="x", padx=12, pady=10)
        for i in range(3):
            grid.grid_columnconfigure(i, weight=1)
        presets = [(0, 0, "Środek", 0, 0), (1, 0, "Góra", 0, -1), (2, 0, "Dół", 0, 1),
                   (0, 1, "Lewo", -1, 0), (1, 1, "Prawo", 1, 0), (2, 1, "Reset", None, None)]
        for col, r, text, x, y in presets:
            if x is None:
                ctk.CTkButton(grid, text=text, command=self._frame_reset,
                              **GHOST).grid(row=r, column=col, padx=4, pady=4, sticky="ew")
            else:
                ctk.CTkButton(grid, text=text, command=lambda x=x, y=y: self._frame_preset(x, y),
                              **GHOST).grid(row=r, column=col, padx=4, pady=4, sticky="ew")

    # ------------------------------------------------- zakładka: EFEKTY
    def _tab_fx(self, tab):
        box = self._scroll_tab(tab)
        v = self.video
        self._section(box, "Efekty żywego telefonu")
        self.var_shake = ctk.BooleanVar(value=v.fx_shake if v else True)
        ctk.CTkCheckBox(box, text="Drganie ręki", variable=self.var_shake,
                        command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self.sld_shakeamt, self.val_shakeamt = self._slider_card(
            box, "Siła drgania", v.fx_shake_amount if v else 4.0, 0, 12, 24,
            lambda x: "%.1f" % x, self._on_fx_sliders)
        self.var_grain = ctk.BooleanVar(value=v.fx_grain if v else True)
        ctk.CTkCheckBox(box, text="Ziarno filmu", variable=self.var_grain,
                        command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self.sld_grainamt, self.val_grainamt = self._slider_card(
            box, "Ilość ziarna", v.fx_grain_amount if v else 6.0, 0, 25, 25,
            lambda x: "%.1f" % x, self._on_fx_sliders)
        self.var_vig = ctk.BooleanVar(value=v.fx_vignette if v else True)
        self.var_af = ctk.BooleanVar(value=v.fx_autofocus if v else True)
        for text, var in (("Winieta", self.var_vig), ("Animowany autofocus", self.var_af)):
            ctk.CTkCheckBox(box, text=text, variable=var,
                            command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self._hint(box, "Efekty sprawiają, że obraz wygląda jak nagranie z ręki.")

    # -------------------------------------------------------------- playlista
    def _refresh_playlist_ui(self):
        for w in self.playlist_box.winfo_children():
            w.destroy()
        if not self.video or not self.video.playlist:
            ctk.CTkLabel(self.playlist_box, text="Pusto.\nDodaj zdjęcia lub nagrania.",
                         text_color=MUTED, justify="center").pack(padx=6, pady=14)
            return
        for i, item in enumerate(self.video.playlist):
            name = os.path.basename(item["path"])
            if len(name) > 30:
                name = name[:27] + "…"
            mark = "▸" if item["type"] == "video" else "•"
            cur = (i == self.video.index)
            sel = (i == self._sel_idx)
            if cur:
                fg, tc, bw = WHITE, "black", 0
            elif sel:
                fg, tc, bw = "transparent", TEXT, 1
            else:
                fg, tc, bw = "transparent", MUTED, 0
            b = ctk.CTkButton(self.playlist_box, text="%s  %s" % (mark, name),
                              anchor="w", fg_color=fg, text_color=tc, hover_color=CARD2,
                              border_width=bw, border_color=LINE,
                              corner_radius=9, height=32, font=ctk.CTkFont(size=12),
                              command=lambda i=i: self._select_slide(i))
            b.pack(fill="x", padx=4, pady=2)

    def _select_slide(self, i):
        self._sel_idx = i
        if self.video:
            self.video.goto(i)
        self._refresh_playlist_ui()

    def _on_slide_change(self, idx):
        self._sel_idx = idx
        try:
            self.after(0, self._refresh_playlist_ui)
        except Exception:
            pass

    def _add_files(self):
        exts = [("Media", "*.jpg *.jpeg *.png *.webp *.bmp *.mp4 *.avi *.mkv *.mov *.webm *.m4v *.3gp"),
                ("Wszystkie", "*.*")]
        paths = filedialog.askopenfilenames(title="Wybierz zdjęcia / nagrania", filetypes=exts)
        if paths and self.video:
            n = self.video.add_files(list(paths))
            self._log("Dodano %d plików." % n)
            self._refresh_playlist_ui()

    def _add_folder(self):
        folder = filedialog.askdirectory(title="Wybierz folder ze zdjęciami / nagraniami")
        if folder and self.video:
            n = self.video.add_folder(folder)
            self._log("Dodano %d plików z folderu." % n)
            self._refresh_playlist_ui()

    def _remove_selected(self):
        if self.video:
            i = self._sel_idx
            self.video.remove_at(i)
            self._sel_idx = max(0, min(i, len(self.video.playlist) - 1))
            self._refresh_playlist_ui()

    def _clear_playlist(self):
        if self.video:
            self.video.clear()
            self._sel_idx = 0
            self._refresh_playlist_ui()
            self._log("Wyczyszczono listę.")

    def _move_sel(self, delta):
        if self.video:
            self._sel_idx = self.video.move(self._sel_idx, delta)
            self._refresh_playlist_ui()

    def _slide_next(self):
        if self.video:
            self.video.next(manual=True)
            self._refresh_playlist_ui()

    def _slide_prev(self):
        if self.video:
            self.video.prev()
            self._refresh_playlist_ui()

    # ------------------------------------------------------- obsługa: obraz
    def _restart_vcam_if_live(self, what):
        if self.video and self.video.vcam_active:
            self.video.stop_virtual()
            ok, msg = self.video.start_virtual()
            self._log(msg if ok else "Uwaga: " + msg)
        else:
            self._log(what)

    def _on_mode_change(self, label):
        if self.video:
            self.video.mode = self._key_of(SLIDESHOW_MODES, label)

    def _on_interval_change(self, val):
        if self.video:
            try:
                self.video.interval = float(val)
            except Exception:
                pass

    def _on_trans_change(self, label):
        if self.video:
            self.video.transition = self._key_of(TRANSITIONS, label)

    def _on_format_change(self, label):
        if not self.video:
            return
        for k, v in PHONE_FORMATS.items():
            if v["label"] == label:
                self.video.format_id = k
                self._restart_vcam_if_live("Format: " + label)
                break

    def _on_backend_change(self, label):
        if not self.video:
            return
        for k, v in BACKEND_LABELS.items():
            if v == label:
                self.video.vcam_backend = k
                self._restart_vcam_if_live("Silnik kamery: " + label)
                break

    def _on_fps_change(self, val):
        if not self.video:
            return
        try:
            self.video.fps = int(val)
            self._restart_vcam_if_live("FPS: " + str(val))
        except Exception:
            pass

    def _on_fit_change(self, label):
        if self.video:
            self.video.fit_mode = self._key_of(FIT_MODES, label)

    def _on_filter_change(self, label):
        if self.video:
            self.video.filter_id = self._key_of(FILTERS, label)

    def _rotate(self):
        if self.video:
            self.video.rotate = (self.video.rotate + 90) % 360
            self._log("Obrót: %d°" % self.video.rotate)

    def _on_mirror(self):
        if self.video:
            self.video.mirror = bool(self.var_mirror.get())

    def _on_fx(self):
        if not self.video:
            return
        v = self.video
        v.ov_rec = bool(self.var_rec.get())
        v.ov_timestamp = bool(self.var_ts.get())
        v.ov_brand = bool(self.var_brand.get())
        v.ov_battery = bool(self.var_batt.get())
        v.fx_shake = bool(self.var_shake.get())
        v.fx_grain = bool(self.var_grain.get())
        v.fx_vignette = bool(self.var_vig.get())
        v.fx_autofocus = bool(self.var_af.get())

    def _on_fx_sliders(self):
        if not self.video:
            return
        try:
            self.video.fx_shake_amount = float(self.sld_shakeamt.get())
            self.video.fx_grain_amount = float(self.sld_grainamt.get())
        except Exception:
            pass

    # --------------------------------------- kadrowanie + orientacja
    def _on_frame_sliders(self):
        if not self.video:
            return
        try:
            self.video.set_frame(zoom=self.sld_zoom.get(),
                                 pan_x=self.sld_panx.get(),
                                 pan_y=self.sld_pany.get())
        except Exception:
            pass

    def _sync_frame_ui(self):
        try:
            if not self.video:
                return
            self.sld_zoom.set(self.video.zoom)
            self.sld_panx.set(self.video.pan_x)
            self.sld_pany.set(self.video.pan_y)
            self.val_zoom.configure(text="%.2f×" % self.video.zoom)
            self.val_panx.configure(text="%+.2f" % self.video.pan_x)
            self.val_pany.configure(text="%+.2f" % self.video.pan_y)
        except Exception:
            pass

    def _frame_drag_start(self, e):
        self._drag_last = (e.x, e.y)

    def _frame_drag_move(self, e):
        if not self.video or self._drag_last is None:
            return
        try:
            dx = (e.x - self._drag_last[0]) / 160.0
            dy = (e.y - self._drag_last[1]) / 160.0
            self._drag_last = (e.x, e.y)
            v = self.video
            v.set_frame(pan_x=v.pan_x + dx, pan_y=v.pan_y + dy)
            self._sync_frame_ui()
        except Exception:
            pass

    def _frame_wheel(self, e):
        try:
            steps = (e.delta / 120) if getattr(e, "delta", 0) else 0
            if steps:
                self._frame_zoom_step(1.12 ** steps)
        except Exception:
            pass

    def _frame_zoom_step(self, f):
        if self.video:
            self.video.set_frame(zoom=self.video.zoom * f)
            self._sync_frame_ui()

    def _frame_preset(self, x, y):
        if not self.video:
            return
        z = self.video.zoom
        if (x or y) and z < 1.15:
            z = 1.3
        self.video.set_frame(zoom=z, pan_x=x, pan_y=y)
        self._sync_frame_ui()

    def _frame_reset(self):
        if self.video:
            self.video.reset_frame()
            self._sync_frame_ui()
            self._log("Zresetowano kadr.")

    def _toggle_orientation(self):
        if not self.video:
            return
        new = "landscape" if self.video.orientation == "portrait" else "portrait"
        self.video.set_orientation(new)
        self._restart_vcam_if_live("")
        self._update_orient_btn()
        self._log("Telefon poziomo (panorama)." if new == "landscape" else "Telefon pionowo.")

    def _on_orient_seg(self, val):
        if not self.video:
            return
        want = "landscape" if val == "Poziomo" else "portrait"
        if self.video.orientation != want:
            self._toggle_orientation()
        else:
            self._update_orient_btn()

    def _update_orient_btn(self):
        try:
            land = self.video and self.video.orientation == "landscape"
            self.var_orient.set("Poziomo" if land else "Pionowo")
        except Exception:
            pass

    # ----------------------------------------------------- obsługa: dźwięk
    def _on_profile(self):
        if self.audio:
            self.audio.set_profile(self.var_profile.get())
            self._update_profile_desc()
            self._log("Sceneria: " + self.var_profile.get())

    def _update_profile_desc(self):
        try:
            p = AUDIO_PROFILES.get(self.var_profile.get(), {})
            self.lbl_prof_desc.configure(text=p.get("desc", ""))
        except Exception:
            pass

    def _on_audio_sliders(self):
        if not self.audio:
            return
        try:
            self.audio.set_volume(self.sld_volume.get())
            self.audio.set_noise_level(self.sld_noise.get())
            self.audio.set_event_rate(self.sld_event.get())
            self.audio.set_bass(self.sld_bass.get())
        except Exception:
            pass

    def _on_breath_toggle(self):
        if self.audio:
            self.audio.set_breath(self.var_breath.get())
            self._log("Oddech włączony." if self.var_breath.get() else "Oddech wyciszony.")

    def _on_breath_level(self):
        if self.audio:
            try:
                self.audio.set_breath_level(self.sld_breath.get())
            except Exception:
                pass

    def _on_breath_rate(self):
        if self.audio:
            try:
                self.audio.set_breath_rate(self.sld_brate.get())
            except Exception:
                pass

    def _on_mute(self):
        if self.audio:
            self.audio.set_muted(self.var_mute.get())
            self._log("Mikrofon wyciszony." if self.var_mute.get() else "Mikrofon aktywny.")
            self._update_leds()

    @staticmethod
    def _is_virtual_audio(name):
        n = (name or "").lower()
        return any(k in n for k in ("cable", "vb-audio", "voicemeeter", "virtual", "realme"))

    def _refresh_devices_combo(self):
        names = ["(domyślne)"]
        self._dev_map = {"(domyślne)": None}
        cable_label = None
        try:
            if self.audio and not self.audio.demo_mode:
                cable_only = bool(self.var_cable_only.get())
                for idx, name in self.audio.list_output_devices():
                    if cable_only and not self._is_virtual_audio(name):
                        continue
                    label = "[%d] %s" % (idx, name[:48])
                    names.append(label)
                    self._dev_map[label] = idx
                cidx, _ = self.audio.find_cable_device()
                if cidx is not None:
                    for label, di in self._dev_map.items():
                        if di == cidx:
                            cable_label = label
                            break
        except Exception:
            pass
        # przywróć zapamiętane urządzenie, inaczej CABLE
        saved = CFG["audio"].get("output_device_name", "")
        picked = None
        if saved:
            for label in names:
                if saved.lower() in label.lower():
                    picked = label
                    break
        if picked is None and cable_label is not None:
            picked = cable_label
        try:
            self.opt_outdev.configure(values=names)
            if picked is not None:
                self.var_outdev.set(picked)
            self._update_outdev_label()
            self._update_audio_warn()
        except Exception:
            pass

    def _update_outdev_label(self):
        try:
            if self.audio is None or self.audio.demo_mode:
                self.lbl_outdev.configure(text="Tryb demo — brak modułu audio. Uruchom INSTALUJ.bat.")
            elif len(self._dev_map) <= 1:
                self.lbl_outdev.configure(text="Brak urządzeń. Zainstaluj VB-CABLE i zrestartuj PC.")
            else:
                self.lbl_outdev.configure(text="Wybrane: " + self.var_outdev.get())
        except Exception:
            pass

    def _update_audio_warn(self):
        try:
            if self.audio is None or self.audio.demo_mode:
                self.lbl_audio_warn.configure(
                    text="TRYB DEMO — dźwięk nie jest wysyłany.\nUruchom INSTALUJ.bat, aby włączyć audio.")
            elif len(self._dev_map) <= 1:
                self.lbl_audio_warn.configure(
                    text="Nie wykryto urządzeń audio.\nZainstaluj VB-CABLE i zrestartuj komputer.")
            else:
                self.lbl_audio_warn.configure(text="")
        except Exception:
            pass

    def _on_outdev_change(self):
        try:
            CFG["audio"]["output_device_name"] = self.var_outdev.get()
        except Exception:
            pass
        self._update_outdev_label()
        if not self._is_virtual_audio(self.var_outdev.get()):
            self._log("Uwaga: to nie jest wirtualny kabel — dźwięk pójdzie na głośniki.")
        if self.audio and self._want_engine():
            self._sync_engine(force=True)
            self._log("Wyjście dźwięku: " + self.var_outdev.get())

    def _test_sound(self):
        if not self.audio:
            return
        if self.audio.demo_mode:
            self._log("Test niemożliwy — tryb demo (brak sounddevice). Uruchom INSTALUJ.bat.")
            return
        if self.audio.is_running():
            self._log("Dźwięk już gra.")
            return
        if not self._is_virtual_audio(self.var_outdev.get()):
            self._log("Test na głośnikach — usłyszysz szum. Wybierz CABLE Input, aby grać cicho.")
        dev = self._dev_map.get(self.var_outdev.get())
        self.audio.start(output_device=dev)
        self._update_leds()
        self._log("Test dźwięku (6 s): " + self.var_outdev.get())

        def _stop():
            time.sleep(6)
            if not self.broadcasting and not self._closing:
                try:
                    self.audio.stop()
                    self.after(0, self._update_leds)
                except Exception:
                    pass
        threading.Thread(target=_stop, daemon=True).start()

    # ---------------------------------------------------------- nadawanie
    def _toggle_broadcast(self):
        if self.broadcasting:
            self._stop_broadcast()
        else:
            self._start_broadcast()

    def _start_broadcast(self):
        if (self.audio and not self.audio.demo_mode
                and not self._is_virtual_audio(self.var_outdev.get())):
            if not messagebox.askyesno(
                    "Uwaga — dźwięk na głośnikach",
                    "Wybrane urządzenie (%s) nie wygląda na wirtualny kabel.\n\n"
                    "Szum będzie słyszalny z głośników i może wracać do mikrofonu.\n\n"
                    "Kontynuować mimo to?" % self.var_outdev.get()):
                self._log("Anulowano. Wybierz CABLE Input w zakładce Dźwięk.")
                return
        if self.video:
            ok, msg = self.video.start_virtual()
            self._log(msg if ok else "Uwaga: " + msg)
        if self.audio:
            self._sync_engine(force=True)
            if self.audio.demo_mode:
                self._log("Mikrofon: TRYB DEMO (dźwięk nie wychodzi). Uruchom INSTALUJ.bat.")
            else:
                self._log("Mikrofon nadaje: " + self.var_outdev.get())
                if self.audio.last_error:
                    self._log(self.audio.last_error)
        self.broadcasting = True
        self._log("Nadawanie przez Unity Capture. W komunikatorze wybierz Unity Capture (virtual) i CABLE Output (VB-Audio Virtual Cable).")
        try:
            self.btn_broadcast.configure(text="⏹   Stop nadawania", fg_color="transparent",
                                         text_color=WHITE, border_width=1, border_color=LINE,
                                         hover_color=CARD2)
        except Exception:
            pass
        self._update_leds()

    def _stop_broadcast(self):
        self.broadcasting = False
        try:
            if self.video:
                self.video.stop_virtual()
            self._sync_engine()
        except Exception:
            pass
        self._log("Zatrzymano. Podgląd działa dalej." + (
            " Muzyka gra dalej." if self._want_engine() else ""))
        try:
            self.btn_broadcast.configure(text="▶   Start nadawania", fg_color=WHITE,
                                         text_color="black", border_width=0,
                                         hover_color=WHITE_HOVER)
        except Exception:
            pass
        self._update_leds()

    def _update_leds(self):
        try:
            if self.video and self.video.vcam_active:
                self.dot_cam.configure(text_color=WHITE)
                self.led_cam.configure(text="Kamera  •  nadaje")
            else:
                self.dot_cam.configure(text_color=DIM)
                self.led_cam.configure(text="Kamera  •  podgląd")
            if self.audio and self.audio.is_running() and not self.var_mute.get():
                self.dot_mic.configure(text_color=WHITE)
                self.led_mic.configure(text="Mikrofon  •  nadaje")
            elif self.audio and self.audio.is_running():
                self.dot_mic.configure(text_color=MUTED)
                self.led_mic.configure(text="Mikrofon  •  wyciszony")
            else:
                self.dot_mic.configure(text_color=DIM)
                self.led_mic.configure(text="Mikrofon  •  wyłączony")
            if self.video and self.video.vcam_active and self.video.vcam_device:
                self.lbl_camstatus.configure(text="Silnik: " + self.video.vcam_device)
            elif self.video and self.video.vcam_active:
                self.lbl_camstatus.configure(text="Silnik: aktywny")
            else:
                self.lbl_camstatus.configure(text="")
        except Exception:
            pass

    # ------------------------------------------------------------- tickery
    def _tick_preview(self):
        try:
            if self.video and HAS_PIL:
                frame = self.video.get_preview()
                if frame is not None:
                    try:
                        pw = max(120, self.lbl_preview.winfo_width() - 4)
                        ph = max(160, self.lbl_preview.winfo_height() - 4)
                    except Exception:
                        pw, ph = 280, 560
                    fh, fw = frame.shape[:2]
                    s = min(pw / fw, ph / fh)
                    dw, dh = max(1, int(fw * s)), max(1, int(fh * s))
                    img = Image.fromarray(frame).resize((dw, dh), Image.BILINEAR)
                    ctk_img = ctk.CTkImage(light_image=img, dark_image=img, size=(dw, dh))
                    self.lbl_preview.configure(image=ctk_img, text="")
                    self.lbl_preview.image = ctk_img
                try:
                    self.lbl_fps.configure(text="%.0f fps" % self.video.actual_fps)
                    cur = self.video.current()
                    if cur:
                        self.lbl_slide.configure(
                            text="%d/%d  •  %s" % (self.video.index + 1, len(self.video.playlist),
                                                  os.path.basename(cur["path"])[:26]))
                    else:
                        self.lbl_slide.configure(text="brak mediów")
                    if getattr(self.video, "_frame_changed", False):
                        self.video._frame_changed = False
                        self._sync_frame_ui()
                except Exception:
                    pass
            self._v14_tick()
        except Exception:
            pass
        if not self._closing:
            self.after(40, self._tick_preview)

    def _tick_meters(self):
        try:
            if self.audio:
                lvl = self.audio.get_level()
                if self.var_mute.get():
                    lvl = 0.0
                self.vu_bar.set(max(0.0, min(1.0, lvl)))
            self._update_leds()
            self._v13_tick()
        except Exception:
            pass
        if not self._closing:
            self.after(120, self._tick_meters)

    # ---------------------------------------------------- okno: urządzenia
    def _open_devices_window(self):
        win = ctk.CTkToplevel(self)
        win.title("Urządzenia wirtualne")
        win.geometry("640x620")
        win.configure(fg_color=BG)
        win.grab_set()
        ctk.CTkLabel(win, text="Urządzenia wirtualne", font=ctk.CTkFont(size=17, weight="bold"),
                     text_color=TEXT).pack(anchor="w", padx=16, pady=(14, 2))
        ctk.CTkLabel(win, text="Wybierz jawnie oznaczone urządzenia wirtualne:",
                     text_color=MUTED).pack(anchor="w", padx=16)

        box = ctk.CTkScrollableFrame(win, height=300, fg_color=CARD, corner_radius=12)
        box.pack(fill="both", expand=True, padx=14, pady=8)

        def refresh():
            for w in box.winfo_children():
                w.destroy()
            rows = VD.devices_status_report() if HAS_VD else [("moduł", False, "brak virtual_devices.py")]
            for name, ok, desc in rows:
                mark = "●" if ok else "○"
                ctk.CTkLabel(box, text="%s  %s\n      %s" % (mark, name, desc),
                             font=ctk.CTkFont(size=12), justify="left",
                             text_color=TEXT if ok else MUTED).pack(anchor="w", padx=8, pady=4)
        refresh()

        ctk.CTkButton(win, text="Odśwież status", command=refresh, **GHOST).pack(padx=14, pady=4, fill="x")
        ctk.CTkButton(win, text="Otwórz ustawienia dźwięku Windows",
                      command=lambda: os.startfile("mmsys.cpl"), **PRIMARY).pack(padx=14, pady=4, fill="x")
        ctk.CTkButton(win, text="Diagnozuj Unity Capture (zapisze raport)",
                      command=self._run_diagnose, **GHOST).pack(padx=14, pady=4, fill="x")
        ctk.CTkButton(win, text="ODINSTALUJ WSZYSTKIE KAMERY — także fizyczne",
                      command=self._run_camera_uninstall,
                      fg_color="#7F1D1D", hover_color="#991B1B", text_color="white").pack(padx=14, pady=6, fill="x")
        row = ctk.CTkFrame(win, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=4)
        ctk.CTkButton(row, text="VB-CABLE", width=150,
                      command=lambda: webbrowser.open("https://vb-audio.com/Cable/"),
                      **GHOST).pack(side="left", padx=2)
        ctk.CTkButton(row, text="Unity Capture", width=150,
                      command=lambda: webbrowser.open("https://github.com/schellingb/UnityCapture"),
                      **GHOST).pack(side="left", padx=2)
        ctk.CTkLabel(win, text="Kamera: wyłącznie Unity Capture (wirtualna; zachowuje nazwę sterownika).\n"
                               "Mikrofon: CABLE Output (VB-Audio Virtual Cable). Po instalacji uruchom ponownie komunikator.",
                     text_color=MUTED, font=ctk.CTkFont(size=11)).pack(padx=14, pady=6)

    def _run_camera_uninstall(self):
        warning = (
            "Ta operacja obejmuje WSZYSTKIE wykryte kamery: wbudowane, USB i wirtualne.\n\n"
            "Spróbuje usunąć urządzenia PnP, pakiety sterowników używane wyłącznie przez kamery "
            "oraz rejestracje DirectShow. Kopie zapasowe zapisze w C:\\ProgramData\\CameraDriverBackup.\n\n"
            "Windows może ponownie wykryć kamerę lub przywrócić sterownik systemowy po restarcie. Kontynuować?"
        )
        if not messagebox.askyesno("Usuń wszystkie kamery", warning, icon="warning"):
            return
        if not HAS_VD:
            messagebox.showerror("Usuń wszystkie kamery", "Brak modułu obsługi urządzeń.")
            return
        ps1 = os.path.join(APP_DIR, "scripts", "uninstall_all_cameras.ps1")
        ok, msg = VD.run_camera_uninstaller(ps1)
        self._log(msg)
        if ok:
            messagebox.showinfo(
                "Potwierdź usuwanie",
                "Otwarto okno administratora. Sprawdź listę urządzeń i wpisz dokładnie "
                "REMOVE ALL CAMERAS, jeśli chcesz kontynuować. Anulowanie nie zmieni systemu."
            )
        else:
            messagebox.showerror("Usuń wszystkie kamery", msg)
    def _run_diagnose(self):
        if not HAS_VD:
            return
        ps1 = os.path.join(APP_DIR, "scripts", "diagnose_camera.ps1")
        ok, msg = VD.run_diagnose_script(ps1)
        self._log(msg)
        if ok:
            self._log("Sprawdź DIAGNOZA_KAMERY.txt — sekcja [4] pokazuje, co widzą programy.")

    # -------------------------------------------------------- okno: pomoc
    def _open_help_window(self):
        win = ctk.CTkToplevel(self)
        win.title("Pomoc — Realme 12 Pro Studio")
        win.geometry("680x640")
        win.configure(fg_color=BG)
        txt = ctk.CTkTextbox(win, font=ctk.CTkFont(size=12), fg_color=CARD, text_color=TEXT,
                             corner_radius=12, border_width=1, border_color=LINE)
        txt.pack(fill="both", expand=True, padx=14, pady=14)
        help_text = (
            "REALME 12 PRO STUDIO — INSTRUKCJA\n"
            "══════════════════════════════\n\n"
            "CO TO ROBI?\n"
            "Projektuje zdjęcia i nagrania jako obraz z telefonu\n"
            "do Zooma / Teams / Discorda / Meet i generuje losowe\n"
            "szumy mikrofonu telefonu. Wszystko offline.\n\n"
            "INSTALACJA (raz):\n"
            "1. INSTALUJ.bat -> opcja 1 robi WSZYSTKO sama\n"
            "   (Python, VB-CABLE, skrót na pulpicie),\n"
            "   zwykle BEZ restartu komputera.\n"
            "2. Zainstaluj Unity Capture (link w oknie Urządzenia) i uruchom jego źródło kamery.\n"
            "3. VB-CABLE (vb-audio.com/Cable) → restart komputera\n"
            "4. USTAW_URZADZENIA.bat pokazuje standardowe nazwy urządzeń\n\n"
            "UŻYCIE:\n"
            "1. START_REALME_CAM.bat\n"
            "2. Dodaj media (lewa kolumna lub folder media/)\n"
            "3. Prawa kolumna — zakładki:\n"
            "   Dźwięk — sceneria, poziomy, oddech, wybór urządzenia\n"
            "   Audio — oś czasu muzyki, pauza/wznowienie, odsłuch,\n"
            "           nagrywanie WAV, pauza mikrofonu\n"
            "   AI Wideo — prompt po polsku → AI robi film ze zdjęć\n"
            "           (offline, z lokalną nauką stylu), render i podgląd\n"
            "   Obraz — kadrowanie, filtr, pokaz, nakładki\n"
            "   Kadr — zoom i pozycja (lub myszka na podglądzie)\n"
            "   Efekty — drganie, ziarno, winieta, autofocus\n"
            "4. Pod podglądem: format, pion/poziom, silnik, FPS\n"
            "   i pasek odtwarzacza: ▶/❚❚, ■ stop, suwak czasu,\n"
            "   −5 s/+5 s, „Zapętl nagranie” + „Płynny szew”\n"
            "5. Start nadawania → w komunikatorze wybierz\n"
            "   kamerę Unity Capture (virtual) i mikrofon CABLE Output (VB-Audio Virtual Cable)\n\n"
            "ODTWARZACZ NAGRANIA (pasek pod podglądem):\n"
            "• Pasek pojawia się WYŁĄCZNIE przy nagraniach (mp4/avi/\n"
            "  mkv/mov). Przy zdjęciu nie ma go wcale — pokaz slajdów\n"
            "  nie potrzebuje transportu.\n"
            "• ⏮ / ▶❚❚ / ⏹ / ⏭ — start, pauza i stop bieżącego MP4.\n"
            "  Pauza nie gasi kamery — rozmówca widzi zamrożony obraz.\n"
            "• Suwak czasu = skok w dowolne miejsce (00:04 / 00:10),\n"
            "  dodatkowo −5 s / +5 s."
            "• „Zapętl nagranie” + „Płynny szew” (0–1,2 s): ostatnie\n"
            "  klatki rozpływają się w pierwsze → powtórka bez trzasku.\n"
            "  Wyłączona pętla = stop na ostatniej klatce / następny plik.\n\n"
            "PRYWATNOŚĆ I KLUCZE API (zakładka „Prywatność”) — OPCJA:\n"
            "Domyślnie apka nie ma sieci. Klucz wklejasz, jeśli chcesz:\n"
            "  • mowę z chmury (/audio/speech) — jak nie wyjdzie, wracasz\n"
            "    na silnik lokalny i dowiadujesz się o tym w logu;\n"
            "  • konsultacji planu AI Wideo — „🌐 Zapytaj AI o plan” w\n"
            "    zakładce AI Wideo; model zwraca wyłącznie liczby z listy\n"
            "    pól planu, każda przycinana do zakresu.\n"
            "Trzy osobne zgody: treść tekstu · treść promptu · miniatury\n"
            "zdjęć. Bez kliknięcia zgody nie zostaje wysłany ŻADEN bajt.\n"
            "Klucz mieszka w config.json (plik tekstowy), nigdy w presetach\n"
            "ani w dzienniku. „ⓘ” przy sekcjach opisuje to ludzkimi słowami;\n"
            "„Wyczyść klucze” i reset fabryczny kasują klucz na dobre.\n"
            "Przez czysty http:// klucz poleciałby jawnie — dlatego apka\n"
            "zgadza się na to tylko dla localhost, reszta wymaga https.\n\n"
            "MOWA (TTS) — zakładka „Mowa (TTS)”:\n"
            "Wpisz tekst → wybierz głos (z listy systemowych), tempo i\n"
            "głośność → „Mów do mikrofonu”. Mowa idzie tym samym kablem\n"
            "co szum, więc rozmówca słyszy jedno i drugie (i nagranie WAV).\n"
            "Offline: System.Speech (Windows) / espeak-ng / pyttsx3.\n"
            "Brak głosów? Windows: Ustawienia → Czas i język → Mowa.\n\n"
            "USTAWIENIA (⚙ w górnym pasku):\n"
            "Zapisz/cały stan do pliku JSON, wczytaj bez restartu,\n"
            "presety w folderze presets/, auto-zapis przy zamknięciu\n"
            "(można wyłączyć), Ctrl+S = zapis teraz, „fabryczne” = defaulty.\n\n"
            "MIKROFON NIE DZIAŁA?\n"
            "• Zakładka Dźwięk → Urządzenie wyjściowe → wybierz\n"
            "  CABLE Input. Brak listy = brak VB-CABLE lub restartu PC.\n"
            "• Tryb demo = brak sounddevice → uruchom INSTALUJ.bat.\n"
            "• W komunikatorze wybierz CABLE Output (VB-Audio Virtual Cable).\n\n"
            "KAMERA NIE POJAWIA SIĘ NA LIŚCIE?\n"
            "Zamknij komunikator CAŁKOWICIE i otwórz ponownie.\n"
            "Potem: USTAW_URZADZENIA.bat → DIAGNOZUJ_KAMERE.bat.\n"
            "Nazwy urządzeń pozostają domyślne i jawnie wskazują urządzenia wirtualne.\n\n"
            "ODDECH: włącznik + głębokość + tempo (/min).\n"
            "Odznaczony = oddech wyciszony.\n\n"
            "OŚ CZASU AUDIO (zakładka Audio):\n"
            "Dodaj audio → ▶ odtwarzaj, ❚❚ pauza (pamięta miejsce),\n"
            "■ stop, klik na osi = skok, Pętla, głośność klipu.\n"
            "Muzyka leci RAZEM z szumem mikrofonu.\n"
            "ODSŁUCH = słyszysz u siebie (nie zmienia kabla).\n"
            "NAGRYWANIE = zapis tego, co idzie na wirtualny mikrofon.\n\n"
            "AI WIDEO (zakładka AI Wideo) — darmowe, w 100% offline:\n"
            "1. Dodaj zdjęcia (albo użyj playlisty).\n"
            "2. Napisz prompt, np. \"kinowy film 30 sekund, wolne\n"
            "   najazdy, sepia, cięcia w rytm muzyki\" — albo kliknij\n"
            "   \"Zaproponuj\" / wybierz styl z biblioteki.\n"
            "3. Akceptuj prompt → zobaczysz plan (liczby).\n"
            "4. Renderuj film → plik w folderze output/ → \n"
            "   \"Dodaj do playlisty\", żeby puścić go przez kamerę.\n"
            "AI uczy się lokalnie (ai_learning.json) — bez internetu.\n\n"
            "SKRÓTY: ← → przełączanie slajdów,\n"
            "        SPACJA = pauza/wznowienie muzyki,\n"
            "        CTRL+SPACJA = start/pauza nagrania,\n"
            "        CTRL+→ / CTRL+← = +5 s / −5 s w nagraniu,\n"
            "        CTRL+L = pętla nagrania,  CTRL+S = zapisz ustawienia,\n"
            "        CTRL+R = nagrywanie, CTRL+M = odsłuch.\n"
        )
        txt.insert("1.0", help_text)
        txt.configure(state="disabled")

    # -------------------------------------------------------------- zamykanie
    def _on_close(self):
        self._closing = True
        try:
            if self.video:
                CFG["video"].update({
                    "format_id": self.video.format_id, "fit_mode": self.video.fit_mode,
                    "filter": self.video.filter_id, "fps": self.video.fps,
                    "backend": "unitycapture",
                    "slideshow_mode": self.video.mode, "slideshow_interval": self.video.interval,
                    "transition": self.video.transition, "effect_shake": self.video.fx_shake,
                    "effect_shake_amount": self.video.fx_shake_amount,
                    "effect_grain": self.video.fx_grain,
                    "effect_grain_amount": self.video.fx_grain_amount,
                    "effect_vignette": self.video.fx_vignette,
                    "effect_autofocus": self.video.fx_autofocus, "overlay_rec": self.video.ov_rec,
                    "overlay_timestamp": self.video.ov_timestamp, "overlay_brand": self.video.ov_brand,
                    "overlay_battery": self.video.ov_battery, "mirror": self.video.mirror,
                    "rotate": self.video.rotate,
                    "zoom": self.video.zoom, "pan_x": self.video.pan_x,
                    "pan_y": self.video.pan_y, "orientation": self.video.orientation,
                    "frames": {k: list(v) for k, v in self.video.frame_memory.items()},
                })
            if self.audio:
                CFG["audio"].update({
                    "profile": self.var_profile.get(), "volume": float(self.sld_volume.get()),
                    "noise_level": float(self.sld_noise.get()), "event_rate": float(self.sld_event.get()),
                    "bass": float(self.sld_bass.get()),
                    "breath_on": bool(self.var_breath.get()),
                    "breath_level": float(self.sld_breath.get()),
                    "breath_rate": int(float(self.sld_brate.get())),
                    "output_device_name": self.var_outdev.get(),
                    "cable_only": bool(self.var_cable_only.get()),
                })
            self._v13_on_close()
            self._v14_on_close()
            if CFG.get("ui", {}).get("autosave", True):
                save_config(CFG)
        except Exception:
            pass
        try:
            self._v13_shutdown()
            if self.audio:
                self.audio.stop()
            if self.video:
                self.video.stop()
        except Exception:
            pass
        self.destroy()


def _boost_priority():
    try:
        if sys.platform.startswith("win"):
            import ctypes
            ctypes.windll.kernel32.SetPriorityClass(
                ctypes.windll.kernel32.GetCurrentProcess(), 0x8000)
    except Exception:
        pass


def main():
    _boost_priority()
    try:
        app = RealmeStudioApp()
        app.mainloop()
    except Exception:
        traceback.print_exc()
        try:
            input("\nWystąpił błąd (szczegóły powyżej). Naciśnij ENTER, aby zamknąć…")
        except Exception:
            pass


if __name__ == "__main__":
    main()
